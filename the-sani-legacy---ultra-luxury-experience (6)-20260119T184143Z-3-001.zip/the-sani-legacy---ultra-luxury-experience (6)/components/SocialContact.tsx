
import React from 'react';
import { Facebook } from 'lucide-react';

export const SocialContact: React.FC = () => {
  // Updated with the specific profile ID link provided by the user
  const fbUrl = "https://www.facebook.com/profile.php?id=61565833348711"; 

  return (
    <a 
      href={fbUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-8 right-8 z-50 flex items-center space-x-3 bg-matte-black border border-gold/60 px-8 py-3 rounded-full hover:bg-[#1A1A1A] transition-all duration-500 group shadow-[0_0_20px_rgba(197,160,89,0.2)] pulse-gold shimmer-btn no-underline"
    >
      <Facebook className="w-5 h-5 text-gold group-hover:scale-110 transition-transform duration-500" />
      <span className="text-gold font-luxury text-sm tracking-[0.2em] uppercase">Connect on Facebook</span>
    </a>
  );
};
