
import React from 'react';

export const GoldParticles: React.FC = () => {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {[...Array(20)].map((_, i) => (
        <div
          key={i}
          className="gold-particle"
          style={{
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            animationDelay: `${Math.random() * 15}s`,
            animationDuration: `${10 + Math.random() * 15}s`
          }}
        />
      ))}
    </div>
  );
};

export const CircuitPattern: React.FC = () => (
  <svg className="absolute top-0 right-0 w-full h-full opacity-5 pointer-events-none" viewBox="0 0 800 800">
    <path d="M100 100 L200 100 L200 200 M300 100 L300 300 L400 300" stroke="#C5A059" fill="none" strokeWidth="1" />
    <circle cx="100" cy="100" r="3" fill="#C5A059" />
    <circle cx="200" cy="200" r="3" fill="#C5A059" />
    <circle cx="400" cy="300" r="3" fill="#C5A059" />
  </svg>
);

export const WavePattern: React.FC = () => (
  <svg className="absolute bottom-0 left-0 w-full h-48 opacity-10 pointer-events-none" viewBox="0 0 1000 200">
    <path d="M0 100 Q 250 50 500 100 T 1000 100" stroke="#C5A059" fill="none" strokeWidth="2" />
    <path d="M0 120 Q 250 70 500 120 T 1000 120" stroke="#C5A059" fill="none" strokeWidth="1" opacity="0.5" />
  </svg>
);
