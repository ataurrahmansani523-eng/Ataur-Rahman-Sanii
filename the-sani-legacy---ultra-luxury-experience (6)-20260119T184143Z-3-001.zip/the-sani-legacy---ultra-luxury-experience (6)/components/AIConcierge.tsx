
import React, { useState, useRef, useEffect } from 'react';
import { Message } from '../types';
import { getAIResponse } from '../services/geminiService';
import { Send, User, ShieldCheck, X } from 'lucide-react';

export const AIConcierge: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'Good evening. I am the digital strategist for Ataur Rahman Sani. How may I assist your inquiry into his world?' }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { role: 'user', content: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    const response = await getAIResponse([...messages, userMsg]);
    setMessages(prev => [...prev, { role: 'assistant', content: response }]);
    setIsLoading(false);
  };

  return (
    <>
      {/* Floating Trigger Button */}
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 z-50 flex items-center space-x-3 bg-matte-black border border-gold/60 px-6 py-3 rounded-full hover:bg-[#1A1A1A] transition-all duration-500 group shadow-[0_0_20px_rgba(197,160,89,0.2)] pulse-gold shimmer-btn"
      >
        <ShieldCheck className="w-5 h-5 text-gold group-hover:rotate-[360deg] transition-transform duration-1000" />
        <span className="text-gold font-luxury text-sm tracking-widest">Digital Concierge</span>
      </button>

      {/* Chat Sidebar/Modal */}
      <div className={`fixed inset-y-0 right-0 w-full md:w-[450px] bg-black/95 border-l border-gold/30 z-[60] transform transition-transform duration-1000 ease-in-out backdrop-blur-2xl ${isOpen ? 'translate-x-0 shadow-[-20px_0_100px_rgba(0,0,0,0.8)]' : 'translate-x-full'}`}>
        <div className="h-full flex flex-col p-8">
          <div className="flex justify-between items-center mb-8 border-b border-gold/20 pb-4">
            <div className="transform transition-transform duration-1000" style={{ transform: isOpen ? 'translateX(0)' : 'translateX(20px)' }}>
              <h3 className="font-luxury text-gold tracking-[0.2em] text-lg uppercase">The Strategist</h3>
              <p className="text-[10px] text-gray-400 tracking-[0.3em] uppercase mt-1">Sani Digital Twin v3.0</p>
            </div>
            <button 
              onClick={() => setIsOpen(false)} 
              className="group p-2 text-gold hover:text-white transition-all duration-300 rounded-full border border-transparent hover:border-gold/30"
            >
              <X className="w-5 h-5 group-hover:rotate-90 transition-transform" />
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto space-y-8 pr-4 custom-scrollbar">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-700`}>
                <div className={`max-w-[85%] ${msg.role === 'user' ? 'bg-[#1A1A1A] border border-gold/10' : ''} p-5 rounded-sm shadow-xl`}>
                  <p className={`text-sm leading-relaxed tracking-wide ${msg.role === 'user' ? 'text-gray-300 font-light' : 'text-gold/90 font-serif-elegant italic'}`}>
                    {msg.content}
                  </p>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-[#1A1A1A] p-4 rounded-sm animate-pulse flex space-x-2">
                  <div className="w-1.5 h-1.5 bg-gold/50 rounded-full"></div>
                  <div className="w-1.5 h-1.5 bg-gold/50 rounded-full delay-150"></div>
                  <div className="w-1.5 h-1.5 bg-gold/50 rounded-full delay-300"></div>
                </div>
              </div>
            )}
          </div>

          <div className="mt-8 pt-4 border-t border-gold/20">
            <div className="relative group">
              <input 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Submit an inquiry..."
                className="w-full bg-transparent border-b border-gold/20 py-4 text-sm focus:border-gold outline-none transition-all text-white placeholder:text-gray-600 font-inter tracking-[0.15em]"
              />
              <button 
                onClick={handleSend}
                className="absolute right-0 bottom-4 text-gold hover:text-white transition-all transform hover:scale-110"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
