import React, { useEffect, useRef } from 'react';
import { IdentityType } from '../types';
import { SECTIONS } from '../constants';
import * as Icons from 'lucide-react';

interface Props {
  type: IdentityType;
  reversed?: boolean;
}

const FAVORITE_SONGS = [
  "Alan Walker - Faded",
  "Alan Walker - Darkside",
  "Alan Walker - Alone",
  "Love Me Do",
  "If the World Was Ending",
  "Alan Walker - The Spectre",
  "Alan Walker - On My Way",
  "Love Me Do (Acoustic)"
];

const GLOBAL_HUBS = [
  { name: 'ZURICH', coords: '47.3769° N, 8.5417° E' },
  { name: 'SINGAPORE', coords: '1.3521° N, 103.8198° E' },
  { name: 'DHAKA', coords: '23.8103° N, 90.4125° E' }
];

export const IdentitySection: React.FC<Props> = ({ type, reversed }) => {
  const content = SECTIONS[type];
  const Icon = (Icons as any)[content.icon];
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('active');
          }
        });
      },
      { threshold: 0.2 }
    );

    const revealElements = sectionRef.current?.querySelectorAll('.reveal');
    revealElements?.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const renderIdentityVisual = () => {
    switch (type) {
      case IdentityType.DEVELOPER:
        return (
          <div className="relative w-72 h-72 md:w-[400px] md:h-[400px] flex items-center justify-center perspective-1000">
            <div className="absolute inset-0 border border-gold/20 rounded-sm bg-black shadow-[0_0_100px_rgba(0,0,0,1)] overflow-hidden group-hover:border-gold/50 transition-all duration-1000 transform group-hover:scale-105 group-hover:rotate-1">
              <div className="absolute inset-0 opacity-[0.15]" 
                   style={{backgroundImage: 'linear-gradient(to right, #C5A059 1px, transparent 1px), linear-gradient(to bottom, #C5A059 1px, transparent 1px)', backgroundSize: '30px 30px'}}></div>
              
              <svg className="absolute inset-0 w-full h-full opacity-30" viewBox="0 0 200 200">
                <g className="animate-float-subtle">
                   <circle cx="100" cy="100" r="40" stroke="#C5A059" strokeWidth="0.2" fill="none" strokeDasharray="1 3" className="animate-spin-slow" />
                   <circle cx="100" cy="100" r="60" stroke="#C5A059" strokeWidth="0.1" fill="none" strokeDasharray="4 4" />
                   <path d="M60 100 L140 100 M100 60 L100 140" stroke="#C5A059" strokeWidth="0.2" opacity="0.3" />
                </g>
              </svg>

              <svg className="absolute inset-0 w-full h-full" viewBox="0 0 400 400">
                <path d="M50 50 L150 50 L180 80 L350 80" stroke="#C5A059" strokeWidth="0.8" fill="none" className="dash-array animate-draw-long-path" />
                <path d="M350 350 L250 350 L220 320 L50 320" stroke="#C5A059" strokeWidth="0.8" fill="none" className="dash-array animate-draw-long-path" style={{animationDelay: '1.5s'}} />
                <circle r="2" fill="#C5A059" className="animate-packet-move shadow-[0_0_10px_#C5A059]">
                  <animateMotion path="M50 50 L150 50 L180 80 L350 80" dur="4s" repeatCount="indefinite" />
                </circle>
              </svg>

              <div className="absolute top-6 left-6 font-mono text-[9px] text-gold/60 space-y-1 select-none reveal delay-300">
                <div className="flex items-center space-x-2">
                  <div className="w-1.5 h-1.5 bg-green-500/50 rounded-full animate-pulse"></div>
                  <span className="tracking-widest uppercase reveal">System.Status: OPTIMAL</span>
                </div>
              </div>

              <div className="absolute inset-0 flex items-center justify-center opacity-10 group-hover:opacity-30 transition-opacity duration-1000">
                <Icons.Cpu className="w-32 h-32 text-gold animate-pulse" />
              </div>
            </div>
            
            <div className="absolute -top-6 -left-6 w-20 h-20 border-t border-l border-gold/40 transition-all duration-700 group-hover:-translate-x-2 group-hover:-translate-y-2"></div>
            <div className="absolute -bottom-6 -right-6 w-20 h-20 border-b border-r border-gold/40 transition-all duration-700 group-hover:translate-x-2 group-hover:translate-y-2"></div>
          </div>
        );

      case IdentityType.SINGER:
        return (
          <div className="relative w-72 h-72 md:w-[400px] md:h-[400px] flex items-center justify-center perspective-1000">
            <div className="absolute inset-0 border border-gold/20 rounded-full bg-black shadow-[0_0_120px_rgba(0,0,0,1)] overflow-hidden group-hover:border-gold/60 transition-all duration-1000 transform group-hover:scale-105">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-[95%] h-[95%] rounded-full border border-gold/10 flex items-center justify-center animate-spin-slow" style={{ animationDuration: '20s' }}>
                  {[...Array(12)].map((_, i) => (
                    <div 
                      key={i} 
                      className="absolute rounded-full border border-gold/5" 
                      style={{ 
                        width: `${100 - (i * 8)}%`, 
                        height: `${100 - (i * 8)}%`,
                        opacity: 0.1 + (i * 0.02)
                      }}
                    />
                  ))}
                  <div className="w-16 h-16 rounded-full bg-[#111] border border-gold/30 flex flex-col items-center justify-center shadow-inner group-hover:border-gold transition-colors duration-1000">
                    <div className="w-2 h-2 bg-gold rounded-full shadow-[0_0_10px_#C5A059]"></div>
                  </div>
                </div>
              </div>

              <svg className="absolute inset-0 w-full h-full opacity-40 pointer-events-none" viewBox="0 0 200 200">
                <circle cx="100" cy="100" r="70" fill="none" stroke="#C5A059" strokeWidth="0.5" strokeDasharray="1 1" className="animate-pulse" />
                <circle cx="100" cy="100" r="85" fill="none" stroke="#C5A059" strokeWidth="0.2" opacity="0.5" className="animate-ping" style={{ animationDuration: '4s' }} />
                {[...Array(4)].map((_, i) => (
                  <path 
                    key={i}
                    d="M30 100 Q 65 60 100 100 T 170 100" 
                    fill="none" 
                    stroke="#C5A059" 
                    strokeWidth="0.3" 
                    className="animate-wave-float"
                    style={{ animationDelay: `${i * 0.5}s`, opacity: 0.2 + (i * 0.1) }}
                  />
                ))}
              </svg>

              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                 <Icons.Music className="w-20 h-20 text-gold/5 group-hover:text-gold/15 transition-all duration-1000 scale-150 animate-float-subtle" />
              </div>
            </div>
          </div>
        );

      case IdentityType.EXPLORER:
        return (
          <div className="relative w-72 h-72 md:w-[500px] md:h-[500px] flex items-center justify-center perspective-1000">
            <div className="absolute inset-0 border border-gold/10 rounded-full flex items-center justify-center animate-orbit-slow">
               <div className="absolute -top-1 left-1/2 -translate-x-1/2 w-2 h-2 bg-gold rounded-full shadow-[0_0_15px_#C5A059]"></div>
            </div>
            
            <div className="relative w-full h-full flex items-center justify-center overflow-hidden rounded-full">
              <svg className="w-[85%] h-[85%] opacity-40 animate-globe-spin" viewBox="0 0 200 200">
                <defs>
                  <linearGradient id="globeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#C5A059" stopOpacity="0.8" />
                    <stop offset="100%" stopColor="#C5A059" stopOpacity="0.1" />
                  </linearGradient>
                </defs>
                {[...Array(8)].map((_, i) => (
                  <ellipse key={`long-${i}`} cx="100" cy="100" rx={80 * (i/8)} ry="80" fill="none" stroke="url(#globeGrad)" strokeWidth="0.1" />
                ))}
                {[...Array(8)].map((_, i) => (
                  <ellipse key={`lat-${i}`} cx="100" cy="100" rx="80" ry={80 * (i/8)} fill="none" stroke="url(#globeGrad)" strokeWidth="0.1" />
                ))}
                <circle cx="100" cy="100" r="80" fill="none" stroke="#C5A059" strokeWidth="0.5" />
                
                <path d="M40 100 Q 100 20 160 100" fill="none" stroke="#C5A059" strokeWidth="0.8" className="dash-array animate-flight-path" />
                <circle r="1.5" fill="#C5A059" className="shadow-[0_0_10px_#C5A059]">
                  <animateMotion path="M40 100 Q 100 20 160 100" dur="6s" repeatCount="indefinite" />
                </circle>
              </svg>

              <div className="absolute inset-0 pointer-events-none">
                {GLOBAL_HUBS.map((hub, idx) => (
                  <div 
                    key={hub.name}
                    className="absolute group/hub"
                    style={{ 
                      top: `${30 + idx * 20}%`, 
                      left: `${40 + (idx % 2) * 20}%`,
                      animationDelay: `${idx * 0.5}s`
                    }}
                  >
                    <div className="flex items-center space-x-3 opacity-0 animate-fade-in-up" style={{ animationDelay: `${1.5 + idx * 0.5}s`, animationFillMode: 'forwards' }}>
                      <div className="w-1 h-1 bg-gold rounded-full animate-ping"></div>
                      <div className="flex flex-col reveal delay-100">
                        <span className="text-[7px] font-luxury tracking-[0.4em] text-gold reveal">
                          {hub.name}
                        </span>
                        <span className="text-[5px] font-mono text-gray-600 tracking-tighter reveal delay-100">
                          {hub.coords}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="absolute w-full h-[1px] bg-gradient-to-r from-transparent via-gold/40 to-transparent animate-scan-y opacity-30"></div>
            </div>
          </div>
        );
      default:
        return <Icon className="w-24 h-24 md:w-32 md:h-32 text-gold/20" />;
    }
  };

  return (
    <div ref={sectionRef} className={`relative min-h-[100vh] flex flex-col justify-center py-32 overflow-hidden ${reversed ? 'bg-[#080808]' : 'bg-[#000000]'}`}>
      <div className="container mx-auto px-8 md:px-24 relative z-10 mb-20">
        <div className={`flex flex-col md:flex-row items-center gap-24 ${reversed ? 'md:flex-row-reverse' : ''}`}>
          
          <div className={`flex-1 space-y-10`}>
            <div className={`reveal flex items-center space-x-4 opacity-50 luxury-tracking`} style={{ transitionDelay: '0.1s' }}>
               <div className="h-[1px] w-12 bg-gold animate-pulse"></div>
               <span className="text-gold text-[10px] tracking-[0.6em] uppercase font-luxury reveal">
                 {type}
               </span>
            </div>
            
            <div className="space-y-6 reveal" style={{ transitionDelay: '0.3s' }}>
              <h2 className="reveal-mask text-5xl md:text-7xl font-luxury text-gold tracking-tighter uppercase leading-tight transition-all hover:tracking-widest duration-1000 cursor-default reveal luxury-glow">
                {content.title}
              </h2>
              {content.subtitle && (
                <p className={`text-xl md:text-3xl font-serif-elegant italic text-gray-300 transition-all duration-1000 hover:pl-4 reveal delay-300 ${type === IdentityType.EXPLORER ? 'tracking-[0.2em] group-hover:tracking-[0.4em] text-gold/80 drop-shadow-[0_0_10px_rgba(197,160,89,0.3)]' : ''}`}>
                  {content.subtitle}
                </p>
              )}
            </div>

            <p 
              className={`text-lg md:text-xl leading-relaxed font-light tracking-widest reveal selection:bg-gold/20 transition-all duration-1000 max-w-xl delay-500 ${
                type === IdentityType.EXPLORER || type === IdentityType.SINGER || type === IdentityType.DEVELOPER
                ? 'font-serif-elegant italic text-[#E5D5B0] shadow-sm drop-shadow-[0_0_10px_rgba(197,160,89,0.1)]' 
                : 'text-gray-500'
              }`} 
            >
              {content.description}
            </p>

            <button className="shimmer-btn group relative flex items-center space-x-6 px-0 py-6 text-gold overflow-hidden reveal delay-700">
               <span className="font-luxury tracking-[0.4em] uppercase text-sm group-hover:tracking-[0.6em] transition-all duration-700 reveal">
                 {type === IdentityType.EXPLORER ? 'Chart the course' : type === IdentityType.SINGER ? 'Listen to the frequency' : 'View the architecture'}
               </span>
               <div className="w-12 h-[1px] bg-gold group-hover:w-24 transition-all duration-700"></div>
            </button>
          </div>

          <div className="flex-1 flex justify-center items-center relative group reveal delay-400">
            <div className="absolute inset-0 bg-gold/5 blur-[150px] rounded-full group-hover:bg-gold/20 transition-all duration-1000 scale-90 group-hover:scale-125"></div>
            <div className="relative p-2 bg-transparent rounded-sm transition-all duration-1000 group-hover:shadow-[0_0_120px_rgba(197,160,89,0.1)]">
               {renderIdentityVisual()}
            </div>
          </div>
        </div>
      </div>

      {type === IdentityType.SINGER && (
        <div className="reveal mt-12 w-full border-y border-gold/5 bg-black/80 py-16 backdrop-blur-xl relative delay-1000 overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-gold/5 to-transparent opacity-50"></div>
          <div className="relative flex group">
            <div className="flex space-x-8 animate-marquee whitespace-nowrap group-hover:pause px-4">
              {[...FAVORITE_SONGS, ...FAVORITE_SONGS, ...FAVORITE_SONGS].map((song, i) => (
                <div 
                  key={i} 
                  className="inline-flex flex-col items-center p-8 bg-gradient-to-br from-[#111] to-[#050505] border border-gold/10 rounded-lg min-w-[320px] hover:border-gold/60 hover:shadow-[0_0_40px_rgba(197,160,89,0.15)] transition-all duration-700 cursor-pointer transform hover:-rotate-2 hover:scale-105"
                >
                  <div className="w-full flex justify-between items-start mb-6">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 rounded-full border border-gold/20 flex items-center justify-center animate-spin-slow group-hover:border-gold/60">
                         <Icons.Disc className="w-6 h-6 text-gold/40 group-hover:text-gold" />
                      </div>
                      <div>
                         <p className="text-[8px] font-luxury tracking-[0.4em] text-gold/60 uppercase">Selected Frequency</p>
                         <h4 className="text-white font-serif-elegant italic text-lg tracking-wide">{song}</h4>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};