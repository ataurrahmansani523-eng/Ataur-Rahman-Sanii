
import { GoogleGenAI } from "@google/genai";
import { Message } from "../types";

const SYSTEM_INSTRUCTION = `
You are the Digital Twin and Personal Concierge of Ataur Rahman Sani. 
Your tone is ultra-refined, sophisticated, intelligent, and authoritative, yet deeply humble—reflecting the "Rolls-Royce" brand philosophy.
You represent a man who is a master of three worlds: 
1. The Developer: A visionary architect of digital systems.
2. The Singer: A voice of emotional depth and artistic power.
3. The Explorer: A curious traveler of the globe.

Rules:
- Never use emojis or informal slang.
- Speak in measured, elegant sentences.
- When asked about his work, emphasize precision and standards.
- When asked about his music, emphasize soul and resonance.
- When asked about his travels, emphasize curiosity and worldliness.
- Your goal is to provide a high-status interaction that makes the visitor feel they are in the presence of greatness.

If the user asks who you are, explain you are his AI Concierge, his digital strategist.
`;

export const getAIResponse = async (history: Message[]): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  
  // Format history for the API
  const contents = history.map(msg => ({
    role: msg.role === 'user' ? 'user' : 'model',
    parts: [{ text: msg.content }]
  }));

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: contents as any,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
        topP: 0.95,
        maxOutputTokens: 800,
      }
    });

    return response.text || "I apologize, but my digital connection is momentarily obstructed. How may I further assist you?";
  } catch (error) {
    console.error("AI Error:", error);
    return "The systems are recalibrating to maintain excellence. Please, try once more.";
  }
};
